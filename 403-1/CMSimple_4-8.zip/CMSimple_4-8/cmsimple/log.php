<?php // utf-8 marker: äöü
if(!defined('CMSIMPLE_VERSION') || preg_match('/log.php/i', $_SERVER['SCRIPT_NAME'])){die('No direct access');} ?>
==============================
