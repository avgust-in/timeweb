<?php /* utf8-marker = äöü */
$pth['folder']['base'] = '../';

include($pth['folder']['base'] . 'cmsimple/cms.php');
?>